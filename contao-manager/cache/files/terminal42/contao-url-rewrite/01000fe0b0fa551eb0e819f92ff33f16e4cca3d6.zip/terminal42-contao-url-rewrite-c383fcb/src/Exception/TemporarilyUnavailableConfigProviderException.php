<?php

declare(strict_types=1);

namespace Terminal42\UrlRewriteBundle\Exception;

class TemporarilyUnavailableConfigProviderException extends \RuntimeException
{
}
